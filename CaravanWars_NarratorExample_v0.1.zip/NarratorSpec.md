# CaravanWars – LLM Narrator Hybrid Spec (v0.1)

> Short version (PL): LLM opowiada i wybiera **tagi z białej listy**, a **silnik gry liczy liczby** z `rules.json`. Dzięki temu mamy klimat („długi, dobrej jakości miecz”), ale wynik walki jest powtarzalny i fair.

## 1) Goals
- Keep *descriptive items* (e.g., “long, good-quality sword”) while all math stays deterministic.
- Use LLM *only* to infer allowed context tags (terrain, posture, situational cues) and generate prose.
- Make every combat decision explainable via a machine log (“why it happened”).

## 2) Architecture (high-level)
```
Player intent/description ──► LLM Narrator ──► {selected_tags}
                                           └─► prose narration
                    rules.json + whitelist ──► Engine computes outcome (deterministic RNG)
                                              └─► Explanation Log + Tooltips
```
- **LLM output is non-authoritative**: it must be validated against a whitelist and never inject numbers.
- **Engine** uses canonical rules (this repo’s `rules.json`) and a seeded RNG to compute outcomes.
- **Log** collects which tags & rules were applied (for UI tooltip “Why did this happen?”).

## 3) Canonical tags (examples)
- `weapon.longsword`, `weapon.shortbow`, `weapon.crossbow`, `weapon.mace`
- `armor.chainmail`, `armor.gambeson`
- `shield.round_shield`
- `quality.poor|common|good|master`
- `terrain.mud|slippery`
- `posture.hold_node|charge`
- `formation.shield_wall`
- `target_priority.archers|leader|melee`
- `material.steel|wood`
- `condition.fine|worn`

> Add more tags freely as content grows, but remember to put them into the **whitelist** and `rules.json` first.

## 4) LLM ► Engine API contract
**Input to LLM** (example):
```json
{
  "locale": "pl-PL",
  "context": {
    "attacker": {
      "weapon": "long, good-quality sword (steel)",
      "posture": "advance, keep formation"
    },
    "defender": {
      "armor": "chainmail and round shield (front)"
    },
    "environment": "muddy ford; light rain; narrow bridge"
  },
  "whitelist": {
    "tags": ["weapon.longsword","quality.good","material.steel","armor.chainmail","shield.round_shield",
             "terrain.mud","posture.hold_node","posture.charge","formation.shield_wall",
             "target_priority.archers","target_priority.leader","target_priority.melee"]
  }
}
```

**Expected LLM output** (authoritative only for TAGS; prose is cosmetic):
```json
{
  "selected_tags": ["weapon.longsword","quality.good","material.steel","armor.chainmail","shield.round_shield","terrain.mud"],
  "narration": "Długi miecz dosięga pierwszy, lecz kolczuga tłumi część cięć; błoto utrudnia pewne stanie.",
  "confidence": 0.82
}
```

## 5) Validation rules
- Every `selected_tags[i]` must exist in `whitelist.tags` (subset check).
- The Engine will ignore any tag not present in `rules.json` (but log it as `unknown_tag`).
- Numeric effects are sourced **only** from `rules.json`.
- Clamps (see `rules.json.clamps`) bound per-tag and total modifiers.

## 6) Deterministic RNG (seeded)
Seed format (recommendation): `matchId + ":" + turn + ":" + attackerId + ":" + defenderId`  
Use a simple PRNG like mulberry32 or splitmix64 for reproducibility across platforms.

## 7) Engine logic (simplified sketch)
1. Resolve base weapon stats by archetype (e.g., `weapon.longsword.base_damage=[5,8]`).
2. Apply quality/material/posture/formation/terrain modifiers (multiplicative), per `rules.json`.
3. Apply armor/shield interactions (e.g., `vs_armor.chainmail.slashing=0.8`).  
4. Clamp per-tag and total modifier effects.
5. Roll damage with seeded RNG; produce **Explanation Log** with each factor.

## 8) Explanation Log
Example entry (engine-produced, not LLM):
```json
{
  "seed": "skirmish42:3:unitA:unitB",
  "applied": [
    {"rule":"weapon.longsword.base_damage","value":[5,8]},
    {"rule":"quality.good.dmg_mult","value":1.1},
    {"rule":"vs_armor.chainmail.slashing","value":0.8},
    {"rule":"terrain.mud.melee_accuracy_mult","value":0.95}
  ],
  "rolls": {"base":7,"final":5.852},
  "clamps": {"per_tag":"within","total":"within"}
}
```

## 9) Files in this example
- `rules.json` — canonical numeric rules + whitelist + clamps.
- `src/ts/validator.ts` — minimal validator & helpers (TypeScript).
- `src/java/Validator.java` — minimal validator stub (Java).
- `examples/` — sample context & outputs.

## 10) Security/abuse guardrails
- Reject tags outside whitelist.
- Enforce hard clamps.
- Ignore unknown tags (log for telemetry).
- Server-authoritative computation (never trust client-LLM).

## 11) License
CC BY-NC 4.0 (change as needed for the project).
