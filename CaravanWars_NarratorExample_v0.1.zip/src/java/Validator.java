// src/java/Validator.java
// Minimal validator stub for CaravanWars LLM Narrator output.
// This is a sketch for integration; plug into your actual rules/engine classes.

import java.util.*;
import java.util.stream.Collectors;

public class Validator {

    public static class Result {
        public final boolean ok;
        public final List<String> selected;
        public final List<String> invalid;
        public Result(boolean ok, List<String> selected, List<String> invalid) {
            this.ok = ok; this.selected = selected; this.invalid = invalid;
        }
    }

    public static Result validateSelectedTags(List<String> selectedTags, Collection<String> whitelist) {
        Set<String> wl = new HashSet<>(whitelist);
        List<String> selected = selectedTags.stream().filter(wl::contains).collect(Collectors.toList());
        List<String> invalid = selectedTags.stream().filter(t -> !wl.contains(t)).collect(Collectors.toList());
        return new Result(invalid.isEmpty(), selected, invalid);
    }

    public static double clamp(double x, double lo, double hi) {
        return Math.max(lo, Math.min(hi, x));
    }

    // Example usage
    public static void main(String[] args) {
        List<String> selected = Arrays.asList("weapon.longsword","terrain.mud","unknown.tag");
        List<String> wl = Arrays.asList("weapon.longsword","terrain.mud");
        Result r = validateSelectedTags(selected, wl);
        System.out.println("ok=" + r.ok + ", selected=" + r.selected + ", invalid=" + r.invalid);
    }
}
