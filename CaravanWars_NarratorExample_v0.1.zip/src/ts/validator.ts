// src/ts/validator.ts
// Minimal validator + helpers for CaravanWars LLM Narrator output
// Authoritative numbers must come from rules.json (server side).

export type NarratorOutput = {
  selected_tags: string[];
  narration: string;
  confidence?: number;
};

export type Rules = any; // Keep simple in the stub

export function validateNarratorOutput(
  out: NarratorOutput,
  whitelist: Set<string>
): { ok: boolean; invalid: string[]; selected: string[] } {
  const invalid: string[] = [];
  const selected: string[] = [];
  for (const t of out.selected_tags || []) {
    if (whitelist.has(t)) selected.push(t);
    else invalid.push(t);
  }
  return { ok: invalid.length === 0, invalid, selected };
}

// --- Deterministic RNG (mulberry32) ---
export function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seedFromString(s: string): number {
  // Simple FNV-1a hash for demo purposes
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// --- Clamp helpers ---
export function clamp(x: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, x));
}

// --- Very small demo 'compute' to illustrate flow ---
type Unit = {
  weapon: "weapon.longsword" | "weapon.shortbow" | "weapon.crossbow" | "weapon.mace";
  quality: "quality.poor" | "quality.common" | "quality.good" | "quality.master";
  material?: "material.steel" | "material.wood";
  armor?: "armor.chainmail" | "armor.gambeson";
};

export function demoComputeDamage(
  attacker: Unit,
  defender: Unit,
  tags: string[],
  rules: Rules,
  seedKey: string
) {
  const clamps = rules.clamps || { per_tag_mult_min: 0.8, per_tag_mult_max: 1.2, total_mult_min: 0.6, total_mult_max: 1.6 };
  const rng = mulberry32(seedFromString(seedKey));

  // 1) Base weapon
  const wKey = attacker.weapon.replace("weapon.", "");
  const w = rules.archetypes.weapon[wKey];
  const baseMin = w.base_damage[0], baseMax = w.base_damage[1];
  const baseRoll = baseMin + Math.floor(rng() * (baseMax - baseMin + 1));

  // 2) Quality
  const qKey = attacker.quality.replace("quality.", "");
  let mult = (rules.qualities[qKey]?.dmg_mult ?? 1.0);

  // 3) Armor interaction (use first damage type)
  const type = w.damage_types[0]; // e.g. 'slashing'
  if (defender.armor) {
    const aKey = defender.armor.replace("armor.", "");
    const vs = (rules.vs_armor[aKey]?.[type] ?? 1.0);
    mult *= vs;
  }

  // 4) Terrain (if any in tags)
  if (tags.includes("terrain.mud")) mult *= (rules.terrain.mud.melee_accuracy_mult ?? 1.0);
  if (tags.includes("formation.shield_wall")) mult *= (rules.formation["shield_wall"].ranged_damage_taken_mult ?? 1.0); // illustrative

  // Clamp total multiplier
  mult = clamp(mult, clamps.total_mult_min, clamps.total_mult_max);

  const final = baseRoll * mult;

  return {
    baseRoll,
    type,
    mult,
    final
  };
}
